package com.a11k.temprootlab

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val bg = Color.rgb(11, 11, 18)
    private val card = Color.rgb(25, 25, 38)
    private val purple = Color.rgb(139, 92, 246)
    private val muted = Color.rgb(165, 165, 184)
    private val white = Color.rgb(245, 245, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        scanDevice()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(content)
        setContentView(scroll)

        content.addView(label("A11K TEMPROOT LAB", 13, purple, true))
        content.addView(label("Device compatibility scanner", 24, white, true).apply {
            setPadding(0, dp(8), 0, dp(5))
        })
        content.addView(label("Pemeriksaan aman untuk OPPO CPH2071", 14, muted, false))
        content.addView(space(20))

        val statusCard = panel()
        statusCard.addView(label("DEVICE STATUS", 12, muted, true))
        statusCard.addView(label("Belum dipindai", 22, white, true).apply { tag = "overall" })
        statusCard.addView(label("Scanner hanya membaca informasi perangkat; tidak menjalankan exploit.", 13, muted, false))
        content.addView(statusCard)

        content.addView(space(14))
        val scan = Button(this).apply {
            text = "SCAN DEVICE"
            textSize = 14f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(purple, 14)
            setOnClickListener { scanDevice() }
        }
        content.addView(scan, LinearLayout.LayoutParams(-1, dp(52)))

        content.addView(space(20))
        content.addView(label("HASIL PEMERIKSAAN", 12, muted, true))
        val details = panel()
        val rows = listOf(
            "Model" to "model",
            "Android" to "android",
            "Build" to "build",
            "Kernel" to "kernel",
            "Security patch" to "patch",
            "Bootloader" to "bootloader",
            "Root indicator" to "root"
        )
        rows.forEach { (title, key) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(10))
            }
            row.addView(label(title.uppercase(), 11, muted, true))
            row.addView(label("—", 15, white, false).apply { tag = key })
            details.addView(row)
            if (title != "Root indicator") details.addView(divider())
        }
        content.addView(details)
        content.addView(space(16))
        content.addView(label("CATATAN", 12, muted, true))
        content.addView(label(
            "Aplikasi ini belum melakukan root dan tidak membuka bootloader. Status bootloader/root dibaca sebagai indikator; hasil dapat tidak tersedia pada sebagian firmware. Kompatibilitas exploit tidak bisa disimpulkan hanya dari versi Android atau kernel.",
            13, muted, false
        ))
        content.addView(space(10))
        content.addView(label("A11K profile target: CPH2071EX_11_A.71 • Android 9 • Kernel 4.9.117", 12, muted, false))
    }

    private fun scanDevice() {
        findViewWithTag<TextView>("overall")?.text = "Pemindaian selesai"
        setValue("model", "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
        setValue("android", "${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}")
        setValue("build", "${Build.DISPLAY}\nType: ${Build.TYPE}")
        setValue("kernel", readCommand("uname -r") ?: "Tidak tersedia")
        setValue("patch", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "Tidak tersedia")
        val locked = readProp("ro.boot.flash.locked")
        val vbmeta = readProp("ro.boot.vbmeta.device_state")
        val bootText = when {
            locked == "1" || vbmeta.equals("locked", true) -> "Locked (indikasi)"
            locked == "0" || vbmeta.equals("unlocked", true) -> "Unlocked (indikasi)"
            else -> "Tidak diketahui dari properti sistem"
        }
        setValue("bootloader", bootText)
        val suFound = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/debug_ramdisk/su")
            .any { java.io.File(it).exists() }
        setValue("root", if (suFound) "Binary su terdeteksi (belum tentu aktif)" else "Binary su tidak terdeteksi")
    }

    private fun readProp(name: String): String? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("getprop", name))
            val value = BufferedReader(InputStreamReader(p.inputStream)).readLine()?.trim()
            p.waitFor()
            value?.takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }

    private fun readCommand(command: String): String? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val value = BufferedReader(InputStreamReader(p.inputStream)).readLine()?.trim()
            p.waitFor()
            value?.takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }

    private fun setValue(key: String, value: String) {
        findViewWithTag<TextView>(key)?.text = value
    }

    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(card, 18)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            gravity = Gravity.START
        }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Color.rgb(48, 48, 64))
        layoutParams = LinearLayout.LayoutParams(-1, dp(1))
    }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
