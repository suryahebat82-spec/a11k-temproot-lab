A11K TEMPROOT LAB — source project v0.1.0

Tujuan:
- Aplikasi diagnostik Android untuk membaca model, Android, build, kernel,
  security patch, indikator bootloader, dan indikator keberadaan binary su.
- Target profil awal: OPPO CPH2071 / Android 9 / build CPH2071EX_11_A.71.

PENTING:
- Ini BUKAN aplikasi temporary root dan tidak menjalankan exploit.
- Tidak membuka bootloader, tidak memasang KernelSU/ReSukiSU, dan tidak
  menjanjikan akses root.
- Status bootloader/root hanya indikator berdasarkan properti sistem dan
  keberadaan file; beberapa firmware dapat menyembunyikan atau mengubahnya.
- Tidak ada akses internet atau pengiriman data.

Build:
- Buka folder project ini di Android Studio.
- Gunakan JDK 17 dan Android SDK Platform 34.
- Sync Gradle, lalu Build > Build APK(s).
- Minimum Android: 9 (API 28).

Rilis ini berupa SOURCE PROJECT, bukan APK yang sudah dikompilasi.
